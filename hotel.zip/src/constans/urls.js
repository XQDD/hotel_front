export const urls = [
  {
    name: "广州分店",
    baseURL: "http://localhost:81/hotel",
    baseUploadURL: "http://localhost/static/hotel",
  },
  {
    name: "北京分店",
    baseURL: "http://localhost:22/hotel",
    baseUploadURL: "http://localhost/static/hotel",
  },
  {
    name: "中山分店",
    baseURL: "http://localhost:33/hotel",
    baseUploadURL: "http://localhost/static/hotel",
  }
]
